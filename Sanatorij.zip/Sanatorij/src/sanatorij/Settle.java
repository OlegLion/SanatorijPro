package sanatorij;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import net.proteanit.sql.DbUtils;

import java.awt.Font;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFormattedTextField;
import javax.swing.table.DefaultTableModel;


public class Settle extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tableSettle;
	private JTextField textDateDoc;
	private JTextField textDateSettle;
	private JLabel lblAmountPeople;
	private JLabel lblSex;
	private JTextField textDateLeaving;
	private JComboBox<String> comboRegion;
	private JComboBox comboSex2;
	private JComboBox comboSex;
	private JFormattedTextField formattedTextAge;
	private JFormattedTextField formattedTextAmountDays;
	private JFormattedTextField formattedTextAmountPeoples;
	private JFormattedTextField formattedTextAge2;
	private JButton btnFind;
	private JButton btnFindName;
	private JFormattedTextField formattedTextNumberDoc;
	private JFormattedTextField formattedTextPeopleName;
	private JFormattedTextField formattedTextAddress;
	private JFormattedTextField formattedTextPeople2Name;
	private int id_Settle;
	private JComboBox comboKindOfDoc;
	private int rowSelected;
	
	/*
	 * Method refresh the table Settle
	 */
	public void refreshTableSettle(){
		try{
			String query = "select number_doc as NumberDoc, people_name, age, sex, date_doc, date_settle, date_leaving, amount_days, amount_peoples, address from settle";
			PreparedStatement pst = MainKurort.connect.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			tableSettle.setModel(new DefaultTableModel(
				new Object[][] {
					{new Integer(1), "Test1", new Integer(1980), "male", null, null, null, new Integer(24), new Integer(1), "Donettsskk"},
					{new Integer(2), "Test1", new Integer(1980), "female", null, null, null, new Integer(24), new Integer(2), "Donettsskk"},
					{new Integer(3), "Test1", new Integer(1980), "male", null, null, null, new Integer(24), new Integer(1), "Donettsskk"},
					{new Integer(12345), "Tetst12345", new Integer(1990), "male", null, null, null, new Integer(24), new Integer(1), "IVF"},
					{new Integer(122), "Oscar", new Integer(1999), "male", null, null, null, new Integer(24), new Integer(1), "GDSGSDFGAFDSGFSGFDSG"},
					{new Integer(112), "Sam", new Integer(1990), "male", null, null, null, new Integer(24), new Integer(1), "Lviv"},
					{new Integer(5), "erewrqewr", new Integer(1998), "male", null, null, null, new Integer(24), new Integer(1), "fdhdf"},
				},
				new String[] {
					"NumberDoc", "people_name", "age", "sex", "date_doc", "date_settle", "date_leaving", "amount_days", "amount_peoples", "address"
				}
			) {
				boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false, false, false, false, false
				};
				public boolean isCellEditable(int row, int column) {
					return columnEditables[column];
				}
			});
			rs.close();
			pst.close();
		}catch (Exception e){
			JOptionPane.showMessageDialog(null, "Error execute query " + e);
		}
		
	}
	
	/*
	 * Method to filing data into combobox Regions
	 */
	public void fillComboRegion(){
		try{
			String query = "select * from region";
			PreparedStatement pst = MainKurort.connect.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			while (rs.next()){
				comboRegion.addItem(rs.getString("region_name"));				
			}
			rs.close();
			pst.close();
		}catch (Exception e){
			JOptionPane.showMessageDialog(null, "Error filing data to combobox Region");
		}
	}
	
	/**
	 *  Filling data into combobox Kindofdoc
	 */
	public void fillComboKindofdoc() {
		try {
			String query = "select * from kindofdoc";
			PreparedStatement pst = MainKurort.connect.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				comboKindOfDoc.addItem(rs.getString("kindofdoc_name"));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/*
	 *  Filling text fields with blank text 
	 */
	public void fillTextFields() {
		formattedTextNumberDoc.setText("");
		formattedTextPeopleName.setText("");
		formattedTextAge.setText("");
		formattedTextAddress.setText("");
		textDateDoc.setText("");
		textDateSettle.setText("");
		textDateLeaving.setText("");
		formattedTextAmountDays.setText("");
		formattedTextAmountPeoples.setText("");
		formattedTextPeople2Name.setText("");
		formattedTextAge2.setText("");
	}
	
	
	/**
	 * Create the frame.
	 */
	public Settle() {
		setTitle("Settle");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1047, 623);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(339, 55, 682, 366);
		contentPane.add(scrollPane);
		
		tableSettle = new JTable();
		tableSettle.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				/*
				 *  Choice table element and show him to text fields
				 */
				try{
					rowSelected = tableSettle.getSelectedRow();
					String findElement = tableSettle.getValueAt(rowSelected, 0).toString();
					String query = "select * from settle where number_doc = '"+findElement+"' ";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					while (rs.next()){
						formattedTextNumberDoc.setText(rs.getString("number_doc"));
						formattedTextPeopleName.setText(rs.getString("people_name"));
						formattedTextAge.setText(rs.getString("age"));
						formattedTextAddress.setText(rs.getString("address"));
						textDateDoc.setText(rs.getString("date_doc"));
						textDateSettle.setText(rs.getString("date_settle"));
						textDateLeaving.setText(rs.getString("date_leaving"));
						formattedTextAmountDays.setText(rs.getString("amount_days"));
						formattedTextAmountPeoples.setText(rs.getString("amount_peoples"));
						id_Settle = rs.getInt("settle_id");
					}
					rs.close();
					pst.close();
					rowSelected = 0;
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "ERROR CHOICE TABLE ITEM");
				}
			}
		});
		scrollPane.setViewportView(tableSettle);
		refreshTableSettle();
		
		JLabel lblNumberDoc = new JLabel("Number doc:");
		lblNumberDoc.setBounds(10, 27, 77, 14);
		contentPane.add(lblNumberDoc);
		
		JLabel lblPeopleName = new JLabel("People name:");
		lblPeopleName.setBounds(10, 62, 77, 14);
		contentPane.add(lblPeopleName);
		
		btnFind = new JButton("Find Number");
		btnFind.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				/*
				 *  Search the document of people 
				 */
				try{
					String query = "select number_doc, people_name, age, address, date_doc, date_settle, amount_days, amount_peoples, sex from settle where number_doc = ?";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					pst.setString(1, formattedTextNumberDoc.getText());
					ResultSet rs = pst.executeQuery();
					// check a searching result
					if (rs.isBeforeFirst()) {
						tableSettle.setModel(DbUtils.resultSetToTableModel(rs));
					}
					else {
						JOptionPane.showMessageDialog(null, "People not found");
					}
					rs.close();
					pst.close();
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "Found ERROR: " + e);
				}
			}
		});
		btnFind.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnFind.setBounds(140, 23, 102, 23);
		contentPane.add(btnFind);
		
		JLabel lblAge = new JLabel("Age:");
		lblAge.setBounds(10, 100, 65, 14);
		contentPane.add(lblAge);
		
		JLabel lblRegion = new JLabel("Region:");
		lblRegion.setBounds(140, 100, 46, 14);
		contentPane.add(lblRegion);
		
		JLabel lblAddress = new JLabel("Address:");
		lblAddress.setBounds(10, 137, 46, 14);
		contentPane.add(lblAddress);
		
		JLabel lblDateDoc = new JLabel("Date doc:");
		lblDateDoc.setBounds(10, 176, 65, 14);
		contentPane.add(lblDateDoc);
		
		textDateDoc = JFormatTextfieldData.createJFormattedTextFieldDate();
		textDateDoc.setBounds(84, 173, 77, 20);
		contentPane.add(textDateDoc);
		textDateDoc.setColumns(10);
		
		JLabel lblDateSettle = new JLabel("Date settle:");
		lblDateSettle.setBounds(183, 176, 59, 14);
		contentPane.add(lblDateSettle);
		
		textDateSettle = JFormatTextfieldData.createJFormattedTextFieldDate();
		textDateSettle.setBounds(252, 173, 77, 20);
		contentPane.add(textDateSettle);
		textDateSettle.setColumns(10);
		
		JLabel lblAmountDays = new JLabel("Amount days:");
		lblAmountDays.setBounds(10, 212, 77, 14);
		contentPane.add(lblAmountDays);
		
		lblAmountPeople = new JLabel("Amount peoples:");
		lblAmountPeople.setBounds(115, 212, 81, 14);
		contentPane.add(lblAmountPeople);
		
		lblSex = new JLabel("Sex:");
		lblSex.setBounds(224, 212, 28, 14);
		contentPane.add(lblSex);
		
		comboSex = new JComboBox();
		comboSex.setModel(new DefaultComboBoxModel(new String[] {"male", "female"}));
		comboSex.setBounds(252, 209, 77, 20);
		contentPane.add(comboSex);
	
		JLabel lblKindOfDoc = new JLabel("Kind of doc:");
		lblKindOfDoc.setBounds(183, 249, 59, 14);
		contentPane.add(lblKindOfDoc);
		
		comboKindOfDoc = new JComboBox();
		comboKindOfDoc.setBounds(248, 246, 81, 20);
		contentPane.add(comboKindOfDoc);
		
		JLabel lblDateLeaving = new JLabel("Date leaving:");
		lblDateLeaving.setBounds(10, 249, 65, 14);
		contentPane.add(lblDateLeaving);
		
		textDateLeaving = JFormatTextfieldData.createJFormattedTextFieldDate();
		textDateLeaving.setBounds(84, 246, 77, 20);
		contentPane.add(textDateLeaving);
		textDateLeaving.setColumns(10);
		
		JLabel lblPeople2Name = new JLabel("People2 name:");
		lblPeople2Name.setBounds(10, 324, 77, 14);
		contentPane.add(lblPeople2Name);
		
		JLabel lblAge2 = new JLabel("Age2:");
		lblAge2.setBounds(247, 324, 35, 14);
		contentPane.add(lblAge2);
		
		JButton btnSave = new JButton("Save");
		// Save options
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				/*
				 * Save data into table Settle
				 */
				try{
					String query = "insert into settle (number_doc, people_name, age, address, date_doc, date_settle, amount_days, amount_peoples, sex, date_leaving, date_planleaving, arrival, people2_name, age2, sex2) "
							+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, (0 + '"+formattedTextAge2.getText()+"'), ?)";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					pst.setString(1, formattedTextNumberDoc.getText());
					pst.setString(2, formattedTextPeopleName.getText().trim());
					pst.setString(3, formattedTextAge.getText());
					pst.setString(4, formattedTextAddress.getText().trim());
					pst.setString(5, textDateDoc.getText());   
					pst.setString(6, textDateSettle.getText());
					pst.setString(7, formattedTextAmountDays.getText());
					pst.setString(8, formattedTextAmountPeoples.getText());
					pst.setString(9, (String)comboSex.getSelectedItem());
					pst.setString(10, textDateLeaving.getText());  
					pst.setString(11, textDateLeaving.getText());   
					pst.setString(12, "1");
					pst.setString(13, formattedTextPeople2Name.getText());
					pst.setString(14, (String)comboSex2.getSelectedItem());
					pst.execute();
					pst.close();
					query = "insert into settle_regions (settle_id, region_id) values ((select settle_id from settle where number_doc = '" +formattedTextNumberDoc.getText()+"'), (select region_id from region where region_name = '"+comboRegion.getSelectedItem()+"'))";
					pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					pst.close();
					query = "insert into settle_kindofdocs (settle_id, kindofdoc_id) values ((select settle_id from settle where number_doc = '"+formattedTextNumberDoc.getText()+"'), (select kindofdoc_id from kindofdoc where kindofdoc_name = '"+comboKindOfDoc.getSelectedItem()+"'))";
					pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					pst.close();
					fillTextFields();
					refreshTableSettle();
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "Error execute query " + e);
				}
			}
		});
		
		btnSave.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnSave.setBounds(36, 398, 86, 23);
		contentPane.add(btnSave);
		
		JButton btnUpdate = new JButton("Update");
		// Update options
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*
				 * Update the data table
				 */
				try{
					String query = "delete from settle_kindofdocs where settle_id = '"+id_Settle+"'";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					pst.close();
					query = "delete from settle_regions where settle_id = '"+id_Settle+"'";
					pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					pst.close();
					query = "insert into settle_regions (settle_id, region_id) values ((select settle_id from settle where number_doc = '"+formattedTextNumberDoc.getText()+"'), (select region_id from region where region_name = '"+comboRegion.getSelectedItem()+"'))";
					pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					pst.close();
					query = "insert into settle_kindofdocs (settle_id, kindofdoc_id) values ((select settle_id from settle where number_doc = '"+formattedTextNumberDoc.getText()+"'), (select kindofdoc_id from kindofdoc where kindofdoc_name = '"+comboKindOfDoc.getSelectedItem()+"'))";
					pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					pst.close();
					query = "update settle set number_doc = '"+formattedTextNumberDoc.getText()+"', people_name = '"+formattedTextPeopleName.getText().trim()+"', age = '"+formattedTextAge.getText()+"', address = '"+formattedTextAddress.getText().trim()+"', date_doc = '"+textDateDoc.getText()+"', date_settle = '"+textDateSettle.getText()+"', amount_days = '"+formattedTextAmountDays.getText()+"', amount_peoples = '"+formattedTextAmountPeoples.getText()+"', sex = '"+comboSex.getSelectedItem()+"', date_leaving = '"+textDateLeaving.getText()+"', people2_name = '"+formattedTextPeople2Name.getText()+"', age2 = (0+'"+formattedTextAge2.getText()+"'), sex2 = '"+comboSex2.getSelectedItem()+"' where settle_id = '"+id_Settle+"' ";
					pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					pst.close();
					fillTextFields();
					refreshTableSettle();
				}catch (Exception eu){
					JOptionPane.showMessageDialog(null, "Update failed ..." + eu);
				}
			}
		});
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnUpdate.setBounds(140, 398, 86, 23);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		// Delete options 
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				/*
				 * Delete one settle people from table Settle
				 */
				int choice = JOptionPane.showConfirmDialog(null, "Do you really want delete data?", "DELETE", JOptionPane.YES_NO_OPTION);
				if (choice == 0){
				try{
					String query = "delete from settle_regions where settle_id = '"+id_Settle+"'";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					pst.close();
					query = "delete from settle_kindofdocs where settle_id = '"+id_Settle+"'";
					pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					pst.close();
					query = "delete from settle where settle_id = '"+id_Settle+"'";
					pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					pst.close();
					refreshTableSettle();
					fillTextFields();
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "ERROR delete data " + e);
				}
				}
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnDelete.setBounds(240, 398, 89, 23);
		contentPane.add(btnDelete);
		
		JLabel lblAfterThatYou = new JLabel("If the people comming not alone, then fill the next field:");
		lblAfterThatYou.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblAfterThatYou.setBounds(10, 288, 332, 14);
		contentPane.add(lblAfterThatYou);
		
		comboRegion = new JComboBox<String>();
		comboRegion.setBounds(181, 97, 148, 20);
		contentPane.add(comboRegion);
		
		JLabel lblSettlePeopleIn = new JLabel("Settle people in Sanatorium");
		lblSettlePeopleIn.setFont(new Font("Serif", Font.ITALIC, 16));
		lblSettlePeopleIn.setBounds(562, 21, 191, 22);
		contentPane.add(lblSettlePeopleIn);
		
		JLabel lblNewLabel = new JLabel("Sex2:");
		lblNewLabel.setBounds(10, 356, 46, 14);
		contentPane.add(lblNewLabel);
		
		comboSex2 = new JComboBox();
		comboSex2.setModel(new DefaultComboBoxModel(new String[] {"", "male", "female"}));
		comboSex2.setSelectedIndex(0);
		comboSex2.setBounds(84, 353, 65, 20);
		contentPane.add(comboSex2);
		
		btnFindName = new JButton("Find Name");
		btnFindName.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					String query = "select number_doc, people_name, age, address, date_doc, date_settle, amount_days, amount_peoples, sex from settle where people_name = ?";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					pst.setString(1, formattedTextPeopleName.getText());
					ResultSet rs = pst.executeQuery();
					if (rs.isBeforeFirst()){
						tableSettle.setModel(DbUtils.resultSetToTableModel(rs));
					}
					else{
						JOptionPane.showMessageDialog(null, "People not found");
					}
					rs.close();
					pst.close();
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "Found ERROR: " + e);
				}
				
			}
		});
		btnFindName.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnFindName.setBounds(255, 23, 102, 23);
		contentPane.add(btnFindName);
		
		try{
			formattedTextAge = new JFormattedTextField(new MaskFormatter("####"));
		}catch (Exception e){
			e.printStackTrace();
		}
		formattedTextAge.setBounds(84, 97, 46, 23);
		contentPane.add(formattedTextAge);
		
		try{
			formattedTextAmountDays = new JFormattedTextField(new MaskFormatter("##"));
		}catch (Exception e){
			e.printStackTrace();
		}
		formattedTextAmountDays.setBounds(84, 209, 21, 17);
		contentPane.add(formattedTextAmountDays);
		
		try{
			formattedTextAmountPeoples = new JFormattedTextField(new MaskFormatter("#"));
		}catch (Exception e){
			e.printStackTrace();
		}
		formattedTextAmountPeoples.setBounds(196, 210, 21, 17);
		contentPane.add(formattedTextAmountPeoples);
		
		try{
			formattedTextAge2 = new JFormattedTextField(new MaskFormatter("####"));
		}catch (Exception e){
			e.printStackTrace();
		}
		formattedTextAge2.setBounds(280, 321, 46, 21);
		contentPane.add(formattedTextAge2);
		
		try{
			formattedTextNumberDoc = new JFormattedTextField(new MaskFormatter("******"));
		}catch (Exception e){
			e.printStackTrace();
		}
		formattedTextNumberDoc.setBounds(84, 25, 46, 20);
		contentPane.add(formattedTextNumberDoc);
		
		try{
			formattedTextPeopleName = new JFormattedTextField(new MaskFormatter("******************************"));
		}catch (Exception e){
			e.printStackTrace();
		}
		formattedTextPeopleName.setBounds(84, 59, 245, 23);
		contentPane.add(formattedTextPeopleName);
		
		try{
			formattedTextAddress = new JFormattedTextField(new MaskFormatter("****************************************"));
		}catch (Exception e){
			e.printStackTrace();
		}
		formattedTextAddress.setBounds(84, 134, 245, 23);
		contentPane.add(formattedTextAddress);
		
		try{
			formattedTextPeople2Name = new JFormattedTextField(new MaskFormatter("*****************************"));
		}catch (Exception e){
			e.printStackTrace();
		}
		formattedTextPeople2Name.setBounds(84, 321, 158, 21);
		contentPane.add(formattedTextPeople2Name);
		try{
		}catch (Exception e){
			e.printStackTrace();
		}
		fillComboRegion();
		fillComboKindofdoc();
	}
}
