package sanatorij;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Font;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JFormattedTextField;
import javax.swing.JComboBox;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JTextField;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.table.DefaultTableModel;

public class Hotel extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tableHotel;
	private JFormattedTextField formattedTextFloor;
	private JFormattedTextField formattedTextRoomNumber;
	private JFormattedTextField formattedTextAmountPlaces;
	private JFormattedTextField formattedTextUsedPlaces;
	private JFormattedTextField formattedTextPlace1;
	private JFormattedTextField formattedTextPlace2;
	private JComboBox comboHotelName;
	private JTextField textBenefits;
	private int hotelID;

	/*
	 * Refresh and fill table Hotel
	 */
	public void refreshTableHotel() {
		try {
			String query = "select hotel_id as 'ID Hotel', hotelname_id as 'Hotel name', floor as 'Floor', room_number as 'Room number', amount_places as 'Amount place', used_places as 'Used place', place1_poseldoc as 'Settle place1', place2_poseldoc as 'Settle place2', benefits as 'Benefits' from hotel";
			PreparedStatement pst = MainKurort.connect.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			tableHotel.setModel(new DefaultTableModel(
				new Object[][] {
					{new Integer(4), new Integer(1), new Integer(101), new Integer(2), new Integer(0), new Integer(0), new Integer(0), null, "1"},
					{new Integer(7), new Integer(2), new Integer(101), new Integer(2), new Integer(0), new Integer(0), new Integer(0), null, "1"},
					{new Integer(8), new Integer(3), new Integer(101), new Integer(2), new Integer(2), new Integer(1), new Integer(2), null, "1"},
					{new Integer(9), new Integer(2), new Integer(201), new Integer(2), new Integer(0), new Integer(0), new Integer(0), null, "1"},
					{new Integer(10), new Integer(2), new Integer(202), new Integer(2), new Integer(2), new Integer(1), new Integer(1), new Integer(0), "1"},
					{new Integer(11), new Integer(2), new Integer(203), new Integer(2), new Integer(1), new Integer(3), new Integer(0), null, "1"},
					{new Integer(12), new Integer(2), new Integer(1), new Integer(101), new Integer(2), new Integer(0), new Integer(0), new Integer(0), ""},
					{new Integer(13), new Integer(6), new Integer(1), new Integer(101), new Integer(2), new Integer(0), new Integer(0), new Integer(0), ""},
					{new Integer(14), new Integer(1), new Integer(1), new Integer(111), new Integer(2), new Integer(0), new Integer(0), new Integer(0), ""},
					{new Integer(15), new Integer(1), new Integer(2), new Integer(112), new Integer(2), new Integer(0), new Integer(0), new Integer(0), ""},
					{new Integer(16), new Integer(2), new Integer(1), new Integer(113), new Integer(2), new Integer(0), new Integer(0), new Integer(0), "0"},
				},
				new String[] {
					"ID Hotel", "Hotel name", "Floor", "Room number", "Amount place", "Used place", "Settle place1", "Settle place2", "Benefits"
				}
			) {
				boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false, false, false, false
				};
				public boolean isCellEditable(int row, int column) {
					return columnEditables[column];
				}
			});
			rs.close();
			pst.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*
	 *  Filling comboBox
	 */
	public void fillComboHotelName() {
		try {
			String query = "select * from hotelname";
			PreparedStatement pst = MainKurort.connect.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				comboHotelName.addItem(rs.getString("hotel_name"));
			}
			rs.close();
			pst.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * Clearing text from the textFilds formattedFields 
	 */
	public void clearText() {
		formattedTextFloor.setText(null);
		formattedTextRoomNumber.setText(null);
		formattedTextAmountPlaces.setText(null);
		formattedTextUsedPlaces.setText(null);
		formattedTextPlace1.setText(null);
		formattedTextPlace2.setText(null);
		textBenefits.setText(null);
	}
	
	
	/**
	 * Create the frame.
	 */
	public Hotel() {
		setTitle("Dictionary Hotel");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 722, 448);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTryBuilding = new JLabel("Working with dictionary Hotel");
		lblTryBuilding.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTryBuilding.setHorizontalAlignment(SwingConstants.CENTER);
		lblTryBuilding.setBounds(220, 21, 263, 28);
		contentPane.add(lblTryBuilding);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(210, 69, 486, 330);
		contentPane.add(scrollPane);
		
		tableHotel = new JTable();
		tableHotel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				/*
				 * Filling the text fields the data with table Hotel   
				 */
				try {
					int row = tableHotel.getSelectedRow();
					String findElement = tableHotel.getValueAt(row, 0).toString();
					String query = "select * from hotel where hotel_id = '"+findElement+"'";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					while (rs.next()){
						formattedTextFloor.setText(rs.getString("floor"));
						formattedTextRoomNumber.setText(rs.getString("room_number"));
						formattedTextAmountPlaces.setText(rs.getString("amount_places"));
						formattedTextUsedPlaces.setText(rs.getString("used_places"));
						formattedTextPlace1.setText(rs.getString("place1_settledoc"));
						formattedTextPlace2.setText(rs.getString("place2_settledoc"));
						textBenefits.setText(rs.getString("benefits"));
						hotelID = rs.getInt("hotel_id");
					}
					rs.close();
					pst.close();
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		scrollPane.setViewportView(tableHotel);
		
		JLabel lblHotelName = new JLabel("Hotel Name:");
		lblHotelName.setBounds(24, 69, 80, 18);
		contentPane.add(lblHotelName);
		
		JLabel lblFloor = new JLabel("Floor:");
		lblFloor.setBounds(24, 98, 80, 18);
		contentPane.add(lblFloor);
		
		JLabel lblRoomNumber = new JLabel("Room number:");
		lblRoomNumber.setBounds(24, 127, 80, 18);
		contentPane.add(lblRoomNumber);
		
		JLabel lblAmountPlaces = new JLabel("Amount places:");
		lblAmountPlaces.setBounds(24, 156, 80, 18);
		contentPane.add(lblAmountPlaces);
		
		JLabel lblUsedPlaces = new JLabel("Used places:");
		lblUsedPlaces.setBounds(24, 184, 80, 18);
		contentPane.add(lblUsedPlaces);
		
		JLabel lblPlace = new JLabel("Place 1:");
		lblPlace.setBounds(24, 213, 80, 18);
		contentPane.add(lblPlace);
		
		JLabel lblPlace_1 = new JLabel("Place 2:");
		lblPlace_1.setBounds(24, 242, 80, 18);
		contentPane.add(lblPlace_1);
		
		JButton btnADD = new JButton("ADD");
		btnADD.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				/*
				 * Add hotel into table Hotel and add data ID into foreign table HBotel_HotelNames
				 */
				try {
					String query = "insert into hotel (hotelname_id, floor, room_number, amount_places, used_places, place1_poseldoc, place2_poseldoc, benefits) values ((select hotelname_id from hotelname where hotel_name = '"+comboHotelName.getSelectedItem()+"'), '"+formattedTextFloor.getText()+"', '"+formattedTextRoomNumber.getText()+"', '"+formattedTextAmountPlaces.getText()+"', '"+formattedTextUsedPlaces.getText()+"', '"+formattedTextPlace1.getText()+"', '"+formattedTextPlace2.getText()+"', '"+textBenefits.getText().trim()+"')";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					clearText();
					pst.close();
					refreshTableHotel();
				}catch (Exception e) {
					JOptionPane.showMessageDialog(null, "Error add data into tables Hotel and Hotel_HotelNames " + e);
				}
			}
		});
		btnADD.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnADD.setBounds(57, 308, 89, 23);
		contentPane.add(btnADD);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				/*
				 * Update data in the table hotel
				 */
				try {
					String query = "update hotel set hotelname_id = (select hotelname_id from hotelname where hotel_name = '"+comboHotelName.getSelectedItem()+"'), floor = ?, room_number = ?, amount_places = ?, used_places = ?, place1_poseldoc = ?, place2_poseldoc = ?, benefits = ? where hotel_id = '"+hotelID+"'";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					//pst.setInt(1, (select hotelname_id from hotelname where hotel_name = '"+comboHotelName.getSelectedItem()+"'));
					pst.setString(1, formattedTextFloor.getText());
					pst.setString(2, formattedTextRoomNumber.getText());
					pst.setString(3, formattedTextAmountPlaces.getText());
					pst.setString(4, formattedTextUsedPlaces.getText());
					pst.setString(5, formattedTextPlace1.getText());
					pst.setString(6, formattedTextPlace2.getText());
					pst.setString(7, textBenefits.getText());
					pst.execute();
					clearText();
					pst.close();
					refreshTableHotel();
				}catch (Exception e) {
					JOptionPane.showMessageDialog(null, "Error updating data in table Hotel " + e);
				}
			}
		});
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnUpdate.setBounds(57, 342, 89, 23);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				/*
				 * Deleting data with table Hotel
				 */
				int choice = JOptionPane.showConfirmDialog(null, "Are you really want delete data from table Hotel?", "Deleting row from table Hotel", JOptionPane.YES_NO_OPTION);
				if (choice == 0) {
					try {
						String query = "delete from hotel where hotel_id = '"+hotelID+"' ";
						PreparedStatement pst = MainKurort.connect.prepareStatement(query);
						pst.execute();
						pst.close();
						clearText();
						refreshTableHotel();
					}catch (Exception e) {
						JOptionPane.showMessageDialog(null, "Error deleting data from table Hotel " + e);
					}
				}
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnDelete.setBounds(57, 376, 89, 23);
		contentPane.add(btnDelete);
		
		try {
			formattedTextRoomNumber = new JFormattedTextField(new MaskFormatter("###"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		formattedTextRoomNumber.setBounds(112, 126, 77, 20);
		contentPane.add(formattedTextRoomNumber);
		
		try {
			formattedTextAmountPlaces = new JFormattedTextField(new MaskFormatter("#"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		formattedTextAmountPlaces.setBounds(111, 155, 78, 20);
		contentPane.add(formattedTextAmountPlaces);
		
		try {
			formattedTextUsedPlaces = new JFormattedTextField(new MaskFormatter("#"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		formattedTextUsedPlaces.setBounds(112, 183, 77, 20);
		contentPane.add(formattedTextUsedPlaces);
		
		try {
			formattedTextPlace1 = new JFormattedTextField(new MaskFormatter("******"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		formattedTextPlace1.setBounds(112, 212, 77, 20);
		contentPane.add(formattedTextPlace1);
		
		try {
			formattedTextPlace2 = new JFormattedTextField(new MaskFormatter("******"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		formattedTextPlace2.setBounds(112, 241, 77, 20);
		contentPane.add(formattedTextPlace2);
		
		try {
			formattedTextFloor = new JFormattedTextField(new MaskFormatter("#"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		formattedTextFloor.setBounds(111, 97, 78, 20);
		contentPane.add(formattedTextFloor);
		
		comboHotelName = new JComboBox();
		comboHotelName.setBounds(112, 67, 78, 20);
		contentPane.add(comboHotelName);
		
		JLabel lblBenefits = new JLabel("Benefits:");
		lblBenefits.setBounds(24, 271, 80, 18);
		contentPane.add(lblBenefits);
		
		textBenefits = new JTextField();
		textBenefits.setBounds(112, 271, 77, 20);
		contentPane.add(textBenefits);
		textBenefits.setColumns(10);
		
		fillComboHotelName();
		refreshTableHotel();
	}
}
