package sanatorij;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JLabel;

import java.awt.Font;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.table.DefaultTableModel;

public class KindOfDoc extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tableKindOfDoc;
	private JLabel lblIDKindOfDoc;
	private JFormattedTextField formattedTextName;
	private JFormattedTextField formattedTextPrice;

	/**
	 *  Refresh table KindOfDoc
	 */
	public void refreshTableKindOfDoc() {
		try {
			String query = "select * from kindofdoc";
			PreparedStatement pst = MainKurort.connect.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			tableKindOfDoc.setModel(new DefaultTableModel(
				new Object[][] {
					{new Integer(1), "Lux", new Double(50000.0)},
					{new Integer(2), "Ways", new Double(15000.0)},
					{new Integer(4), "Simple", new Double(10000.0)},
					{new Integer(5), "Special", new Double(20000.0)},
				},
				new String[] {
					"kindofdoc_id", "kindofdoc_name", "kindofdoc_price"
				}
			) {
				boolean[] columnEditables = new boolean[] {
					false, false, false
				};
				public boolean isCellEditable(int row, int column) {
					return columnEditables[column];
				}
			});
			rs.close();
			pst.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Create the frame.
	 */
	public KindOfDoc() {
		setTitle("Dictionary KindOfDoc");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 710, 404);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDictionaryOfThe = new JLabel("Dictionary of the table KindOfDoc");
		lblDictionaryOfThe.setHorizontalAlignment(SwingConstants.CENTER);
		lblDictionaryOfThe.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblDictionaryOfThe.setBounds(141, 11, 384, 34);
		contentPane.add(lblDictionaryOfThe);
		
		JLabel lblID = new JLabel("ID:");
		lblID.setBounds(19, 56, 37, 21);
		contentPane.add(lblID);
		
		lblIDKindOfDoc = new JLabel("");
		lblIDKindOfDoc.setBounds(66, 56, 46, 21);
		contentPane.add(lblIDKindOfDoc);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(202, 58, 466, 261);
		contentPane.add(scrollPane);
		
		tableKindOfDoc = new JTable();
		tableKindOfDoc.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// Filling text fields from table KindOfDoc
				try {
					int row = tableKindOfDoc.getSelectedRow();
					String fildElement = tableKindOfDoc.getValueAt(row, 0).toString();
					String query = "select * from kindofdoc where kindofdoc_id = '"+fildElement+"' ";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					while (rs.next()) {
						lblIDKindOfDoc.setText(rs.getString("kindofdoc_id"));
						formattedTextName.setText(rs.getString("kindofdoc_name"));
						formattedTextPrice.setText(rs.getString("kindofdoc_price"));
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		scrollPane.setViewportView(tableKindOfDoc);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setBounds(19, 88, 37, 21);
		contentPane.add(lblName);
		
		JLabel lblPrice = new JLabel("Price:");
		lblPrice.setBounds(19, 120, 37, 21);
		contentPane.add(lblPrice);
		
		try {
			formattedTextName = new JFormattedTextField(new MaskFormatter("********************"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		formattedTextName.setBounds(66, 88, 117, 21);
		contentPane.add(formattedTextName);
		
		try {
			formattedTextPrice = new JFormattedTextField(new MaskFormatter("#####.##"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		formattedTextPrice.setBounds(66, 120, 117, 21);
		contentPane.add(formattedTextPrice);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Add kind of documents into table KindOfDoc
				try {
					String query = "select * from kindofdoc where kindofdoc_name = '"+formattedTextName+"' ";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					if (!rs.isBeforeFirst()) {
						query = "insert into kindofdoc (kindofdoc_name, kindofdoc_price) values ('"+formattedTextName.getText().trim()+"', '"+formattedTextPrice.getText()+"')";
						pst = MainKurort.connect.prepareStatement(query);
						pst.execute();
						rs.close();
						pst.close();
						lblIDKindOfDoc.setText("");
						formattedTextName.setText(null);
						formattedTextPrice.setText(null);
						refreshTableKindOfDoc();
					}
					else {
						JOptionPane.showMessageDialog(null, "Duplicate kind of document name, please change it");
					}
				}catch (Exception e) {
					JOptionPane.showMessageDialog(null, "Error add data into table KindOfDoc " + e);
				}
			}
		});
		btnAdd.setBounds(62, 205, 89, 23);
		contentPane.add(btnAdd);
		
		JButton btnNewButton = new JButton("Update");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Update kind of document in table KindOfDoc
				try {
					String query = "update kindofdoc set kindofdoc_name = ?, kindofdoc_price = ? where kindofdoc_id = ?";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					pst.setString(1, formattedTextName.getText().trim());
					pst.setString(2, formattedTextPrice.getText());
					pst.setString(3, lblIDKindOfDoc.getText());
					pst.execute();
					lblIDKindOfDoc.setText("");
					formattedTextName.setText(null);
					formattedTextPrice.setText(null);
					pst.close();
					refreshTableKindOfDoc();
				}catch (Exception e) {
					JOptionPane.showMessageDialog(null, "Error update data in table KindOfDoc");
				}
			}
		});
		btnNewButton.setBounds(62, 250, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Delete");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Delete kind of document from table KindOfDoc
				int choice = JOptionPane.showConfirmDialog(null, "Are you really want delete kind of document from table KindOfDoc? ", "Deleting data from table KindOfDoc", JOptionPane.YES_NO_OPTION);
				if (choice == 0) {
					try {
						String query = "delete from kindofdoc where kindofdoc_id = '"+lblIDKindOfDoc.getText()+"' ";
						PreparedStatement pst = MainKurort.connect.prepareStatement(query);
						pst.execute();
						pst.close();
						lblIDKindOfDoc.setText("");
						formattedTextName.setText(null);
						formattedTextPrice.setText(null);
						refreshTableKindOfDoc();
					}catch (Exception e) {
						JOptionPane.showMessageDialog(null, "Error delete data from table KindOfDoc!");
					}
				}
			}
		});
		btnNewButton_1.setBounds(62, 296, 89, 23);
		contentPane.add(btnNewButton_1);
		refreshTableKindOfDoc();
	}

}
