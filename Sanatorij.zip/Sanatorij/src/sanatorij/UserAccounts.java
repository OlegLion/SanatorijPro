package sanatorij;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JScrollPane;

import net.proteanit.sql.DbUtils;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;

public class UserAccounts extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tableUsers;
	private JLabel lblPassword;
	private JTextField textUserName;
	private JPasswordField textPasswordField;
	private JScrollPane scrollPane;
	private int valueID;

	/**
	 * Filling user table method 
	 */
	
	public void fillTableUser(){
		try{
			String query = "select id as 'User ID', user as 'User Name' from users";
			PreparedStatement pst = MainKurort.connect.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			tableUsers.setModel(new DefaultTableModel(
				new Object[][] {
					{new Integer(2), "user"},
					{new Integer(3), "guest"},
					{new Integer(4), "supervisor"},
					{new Integer(5), "admin"},
				},
				new String[] {
					"User ID", "User Name"
				}
			) {
				boolean[] columnEditables = new boolean[] {
					false, false
				};
				public boolean isCellEditable(int row, int column) {
					return columnEditables[column];
				}
			});
			rs.close();
			pst.close();
		}catch (Exception e){
			JOptionPane.showMessageDialog(null, "Error to filling table data");
		}
	}
	/**
	 * Create the frame.
	 */
	public UserAccounts() {
		setTitle("View and change user accounts");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 727, 460);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(327, 59, 258, 168);
		contentPane.add(scrollPane);
		
		tableUsers = new JTable();
		tableUsers.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
			/*
			 *  Choice table users
			 */
			try{
				int row = tableUsers.getSelectedRow();
				String query = "select * from users where id = ? ";
				PreparedStatement pst = MainKurort.connect.prepareStatement(query);
				pst.setInt(1, (int)tableUsers.getValueAt(row, 0));
				ResultSet rs = pst.executeQuery();
				while (rs.next()){
					textUserName.setText(rs.getString("user"));
					valueID = rs.getInt("id");
				}
				rs.close();
				pst.close();
			}catch (Exception e){
				JOptionPane.showMessageDialog(null, "Error selected item in table");
			}
				
			}
		});
		scrollPane.setViewportView(tableUsers);
		fillTableUser();
		
		JLabel lblUserName = new JLabel("User name");
		lblUserName.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblUserName.setBounds(10, 51, 81, 28);
		contentPane.add(lblUserName);
		
		lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPassword.setBounds(10, 101, 81, 28);
		contentPane.add(lblPassword);
		
		textUserName = new JTextField();
		textUserName.setBounds(103, 52, 166, 26);
		contentPane.add(textUserName);
		textUserName.setColumns(10);
		
		textPasswordField = new JPasswordField();
		textPasswordField.setBounds(103, 101, 166, 26);
		contentPane.add(textPasswordField);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			/*
			 * ADD user and password
			 */
				if (textUserName.getText().isEmpty() || textPasswordField.getText().isEmpty()){
					JOptionPane.showMessageDialog(null, "User name or password is empty");
					return;
				}
   			try{
				String query = "insert into users (user, password) values ('"+textUserName.getText()+"', '"+textPasswordField.getText()+"') ";
				PreparedStatement pst = MainKurort.connect.prepareStatement(query);
				pst.execute();
				pst.close();
				textUserName.setText(null);
				textPasswordField.setText(null);
				fillTableUser();
			}catch (Exception e){
				JOptionPane.showMessageDialog(null, "ERROR add user " + e);
			}
			}
		});
		btnAdd.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAdd.setBounds(10, 188, 89, 23);
		contentPane.add(btnAdd);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			/*
			 * Update users data
			 */
			try{
				int choice = JOptionPane.showConfirmDialog(null, "Do you really want do update user and password?", "UPDATE", JOptionPane.YES_NO_OPTION);
				if (choice == 0){
				String query = "update users set user = '"+textUserName.getText()+"', password = '"+textPasswordField.getText()+"' where id = '"+valueID+"' ";
				PreparedStatement pst = MainKurort.connect.prepareStatement(query);
				pst.execute();
				pst.close();
				textUserName.setText(null);
				textPasswordField.setText(null);
				fillTableUser();
				}
			}catch (Exception e){
				JOptionPane.showMessageDialog(null, "Error update data" + e);
			}
			}
		});
		btnUpdate.setBounds(109, 188, 89, 23);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			/*/
			 * Delete user
			 */
			try{
				int choice = JOptionPane.showConfirmDialog(null, "Do you really want delete user?", "DELETE", JOptionPane.YES_NO_OPTION);
				if (choice == 0){
					String query = "delete from users where id = '"+valueID+"' ";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					pst.close();
					fillTableUser();
				}
			}catch (Exception e){
				JOptionPane.showMessageDialog(null, "ERROR delete user " +e);
			}
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnDelete.setBounds(208, 188, 89, 23);
		contentPane.add(btnDelete);
		
		JLabel lblInThisWindow = new JLabel("ADD, UPDATE or DELETE user name and password");
		lblInThisWindow.setFont(new Font("Serif", Font.ITALIC, 12));
		lblInThisWindow.setBounds(10, 11, 287, 31);
		contentPane.add(lblInThisWindow);
	}
}
