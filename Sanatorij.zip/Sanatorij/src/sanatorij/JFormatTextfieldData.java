package sanatorij;
import javax.swing.JFormattedTextField;
import javax.swing.text.MaskFormatter;

public final class JFormatTextfieldData {
	/**
	 * @wbp.factory
	 */

	public static JFormattedTextField createJFormattedTextFieldDate() {
		JFormattedTextField formattedTextField = new JFormattedTextField();
		try {
		MaskFormatter maskText = new MaskFormatter("####-##-##");
		maskText.setPlaceholderCharacter('_');
		formattedTextField = new JFormattedTextField(maskText);
		}catch (Exception e){
			e.printStackTrace();
		}
		return formattedTextField;
	}
	
	  public static JFormattedTextField createJFormattedTextFieldString() {
	 
		JFormattedTextField formattedTextField = new JFormattedTextField();
		try{
			MaskFormatter maskText = new MaskFormatter("####");
			formattedTextField = new JFormattedTextField(maskText);
		}catch (Exception e){
			e.printStackTrace();
		}
		return formattedTextField;
	}
	
	
}