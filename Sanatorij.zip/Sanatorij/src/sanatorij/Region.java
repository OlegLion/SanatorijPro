package sanatorij;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;

import java.awt.Font;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.SwingConstants;

import net.proteanit.sql.DbUtils;

import javax.swing.JFormattedTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.table.DefaultTableModel;

public class Region extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tableRegion;
	private JLabel lblNewLabel;
	private JLabel lblID;
	private JFormattedTextField formattedTextRegion;
	private JLabel lblRegion;
	private JLabel lblIDRegion;


	/**
	 * Create the frame.
	 */
	
	// fill region table 
	public void refreshTableRegion(){
		try {
			String query = "select region_id as 'Region id number', region_name as 'Region name' from region";
			PreparedStatement pst = MainKurort.connect.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			tableRegion.setModel(new DefaultTableModel(
				new Object[][] {
					{new Integer(20), "Cherkaska"},
					{new Integer(17), "Chernigivska"},
					{new Integer(5), "Chernivetska"},
					{new Integer(15), "Dnipropetrovska"},
					{new Integer(10), "Donetska"},
					{new Integer(16), "Harkivska"},
					{new Integer(18), "Hersonska"},
					{new Integer(6), "I.Frankivska"},
					{new Integer(3), "Khmelnytska"},
					{new Integer(12), "Kirorvogradska"},
					{new Integer(13), "Kyivska"},
					{new Integer(19), "Luganska"},
					{new Integer(1), "Lvivska"},
					{new Integer(9), "Mykolajivska"},
					{new Integer(11), "Poltavska"},
					{new Integer(4), "Rivenska"},
					{new Integer(2), "Ternopilska"},
					{new Integer(8), "Volynska"},
					{new Integer(7), "Zakarpatska"},
					{new Integer(14), "Zaporizgska"},
				},
				new String[] {
					"Region id number", "Region name"
				}
			) {
				boolean[] columnEditables = new boolean[] {
					false, false
				};
				public boolean isCellEditable(int row, int column) {
					return columnEditables[column];
				}
			});
			rs.close();
			pst.close();
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	
	public Region() {
		setTitle("Dictionary Regions");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 843, 584);
		contentPane = new JPanel();
		contentPane.setToolTipText("Dictionary regions");
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel("Dictionary of the regions");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(45, 22, 652, 34);
		contentPane.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(217, 67, 581, 267);
		contentPane.add(scrollPane);
		
		tableRegion = new JTable();
		tableRegion.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					int row = tableRegion.getSelectedRow();
					String findelement = tableRegion.getValueAt(row, 0).toString();
					String query = "select * from region where region_id = '"+findelement+"'";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					while (rs.next()){
						lblIDRegion.setText(rs.getString("region_id"));
						formattedTextRegion.setText(rs.getString("region_name"));
					}
				}catch (Exception e){
					e.printStackTrace();
				}

			}
		});
		scrollPane.setViewportView(tableRegion);
		
		lblID = new JLabel("ID:");
		lblID.setBounds(10, 74, 46, 14);
		contentPane.add(lblID);
		
		try {
			formattedTextRegion = new JFormattedTextField(new MaskFormatter("********************"));
		}catch (Exception e){
			e.printStackTrace();
		}
		formattedTextRegion.setBounds(66, 110, 127, 20);
		contentPane.add(formattedTextRegion);
		
		lblRegion = new JLabel("Region:");
		lblRegion.setBounds(10, 113, 46, 14);
		contentPane.add(lblRegion);
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					// Add data into Region table
					String query = "select * from region where region_name = ?";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					pst.setString(1, formattedTextRegion.getText().trim());
					ResultSet rs = pst.executeQuery();
					if (!rs.isBeforeFirst()){
						query = "insert into region (region_name) values ('"+formattedTextRegion.getText().trim()+"')";
						pst = MainKurort.connect.prepareStatement(query);
						pst.execute();
					}
					else {
						JOptionPane.showMessageDialog(null, "Found a duplicate region name, please check and rewrite it");
					}
					rs.close();
					pst.close();
					lblIDRegion.setText("");
					formattedTextRegion.setText(null);				
					refreshTableRegion();
				}catch (Exception e){
					e.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setBounds(66, 223, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Delete");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// deleting data in Region table
				int choice = JOptionPane.showConfirmDialog(null, "Do you really want delete this region?", "Deleting region", JOptionPane.YES_NO_OPTION);
				if (choice == 0){
					try {
						String query = "delete from region where region_name = ?";
						PreparedStatement pst = MainKurort.connect.prepareStatement(query);
						pst.setString(1, formattedTextRegion.getText().trim());
						pst.execute();
						pst.close();
						lblIDRegion.setText("");
						formattedTextRegion.setText(null);
						refreshTableRegion();
					}catch (Exception e){
						JOptionPane.showMessageDialog(null, "ERROR Deliting data in Region table " + e);
					}
				}
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_1.setBounds(66, 311, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Update data in Region table
				try {
					String query = "update region set region_name = '"+formattedTextRegion.getText().trim()+"' where region_id = '"+lblIDRegion.getText()+"'";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					pst.close();
					lblIDRegion.setText("");
					formattedTextRegion.setText(null);
					refreshTableRegion();
				}catch (Exception e){
					JOptionPane.showMessageDialog(null, "ERROR update data in Region table " + e);
				}
				
			}
		});
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnUpdate.setBounds(66, 266, 89, 23);
		contentPane.add(btnUpdate);
		
		lblIDRegion = new JLabel("");
		lblIDRegion.setBounds(68, 74, 46, 14);
		contentPane.add(lblIDRegion);
		refreshTableRegion();
	}
}
