package sanatorij;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserConfirm extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textUserName;
	private JPasswordField textPassword;

	/**
	 * Create the frame.
	 */
	public UserConfirm() {
		setTitle("User confirmation");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPleaseEnterData = new JLabel("Please enter data");
		lblPleaseEnterData.setHorizontalAlignment(SwingConstants.CENTER);
		lblPleaseEnterData.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblPleaseEnterData.setBounds(147, 47, 122, 14);
		contentPane.add(lblPleaseEnterData);
		
		JLabel lblUserName = new JLabel("User name");
		lblUserName.setBounds(129, 79, 62, 14);
		contentPane.add(lblUserName);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(129, 104, 46, 14);
		contentPane.add(lblPassword);
		
		textUserName = new JTextField();
		textUserName.setBounds(200, 76, 86, 20);
		contentPane.add(textUserName);
		textUserName.setColumns(10);
		
		textPassword = new JPasswordField();
		textPassword.setBounds(200, 101, 86, 20);
		contentPane.add(textPassword);
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/*
				 *Confirm user and password 
				 */
				try{
					String query = "select * from users where user = ? and password = ?";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					pst.setString(1, textUserName.getText());
					pst.setString(2, textPassword.getText());
					ResultSet rs = pst.executeQuery();
					int count = 0;
					while (rs.next()){
						count = count + 1;
					}
					if (count == 0){
						JOptionPane.showMessageDialog(null, "User or password isn't correct");
						return;
					}
					rs.close();
					pst.close();
					JOptionPane.showMessageDialog(null, "W E L C O M E  " + textUserName.getText());

					UserAccounts userFrame = new UserAccounts();
					userFrame.setVisible(true);
					userFrame.setDefaultCloseOperation(1);
				}catch (Exception eu){
					JOptionPane.showMessageDialog(null, "" + eu);
				}
			}
		});
		btnOk.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnOk.setBounds(102, 142, 89, 23);
		contentPane.add(btnOk);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				/*
				 * Exit program
				 */
				int choice = JOptionPane.showConfirmDialog(null, "Do you realy want cancel?", "CANCEL", JOptionPane.YES_NO_OPTION);
				if (choice == 0){
					System.exit(1);
				}
			}
		});
		btnCancel.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnCancel.setBounds(211, 142, 89, 23);
		contentPane.add(btnCancel);
	}
}
