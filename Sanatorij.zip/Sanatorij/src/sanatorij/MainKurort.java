package sanatorij;

import java.awt.EventQueue;
import java.sql.Connection;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.UIManager;

public class MainKurort extends JFrame {

	/**
	 *  Its a main project window 
	 */
	private static final long serialVersionUID = 1L;
	private JFrame frmSettleToSanatorium;
	private Settle settleFrame = null;
	private Region frameRegion = null;
	private HotelName frameHotelName = null;
	private KindOfDoc frameKindOfDoc = null;
	private Hotel frameHotel = null;
	private SettleInTheHouse settleInTheHouse = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Throwable e) {
			e.printStackTrace();
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainKurort window = new MainKurort();
					window.frmSettleToSanatorium.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public static Connection connect = mySqlconnector.dbConnector();
	
	/**
	 * Create the application.
	 */
	public MainKurort() {
		initialize();
		//connect = mySqlconnector.dbConnector();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSettleToSanatorium = new JFrame();
		frmSettleToSanatorium.setTitle("Settle to sanatorium");
		frmSettleToSanatorium.setBounds(100, 100, 988, 597);
		frmSettleToSanatorium.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		frmSettleToSanatorium.setJMenuBar(menuBar);
		
		JMenu mnData = new JMenu("Data");
		menuBar.add(mnData);
		
		JMenuItem mntmSettle = new JMenuItem("Settle");
		mntmSettle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// must add this definition into all internal frame this application
				// to be once open window to item
				if (settleFrame == null || !settleFrame.isDisplayable()){
					settleFrame = new Settle();
					settleFrame.setVisible(true);
					settleFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				}
			}
		});
		mnData.add(mntmSettle);
		
		JMenu mnNewMenu = new JMenu("View");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmSettleInThe = new JMenuItem("Free/used settle in the house");
		mnNewMenu.add(mntmSettleInThe);
		mntmSettleInThe.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			/**
			 * Show settle people in the houses
			 */
				if (settleInTheHouse == null || !settleInTheHouse.isDisplayable()){
					settleInTheHouse = new SettleInTheHouse();
					settleInTheHouse.setVisible(true);
					settleInTheHouse.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				}	
			}
		});
		
		JMenu mnNewMenu_1 = new JMenu("Service");
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmUserAccounts = new JMenuItem("User accounts");
		mntmUserAccounts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				/**
				 * View and change user accounts
				 */
				UserAccounts userFrame = new UserAccounts();
				userFrame.setVisible(true);
				userFrame.setDefaultCloseOperation(1);
			}
		});
		mnNewMenu_1.add(mntmUserAccounts);
		
		JMenu mnNewMenu_2 = new JMenu("Dictionary");
		menuBar.add(mnNewMenu_2);
		
		JMenuItem mntmFreePlaceHouses = new JMenuItem("Hotel");
		mntmFreePlaceHouses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Working with dictionary Hotel
				if (frameHotel == null || !frameHotel.isDisplayable()) {
					frameHotel = new Hotel();
					frameHotel.setVisible(true);
					frameHotel.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				}
			}
		});
		mnNewMenu_2.add(mntmFreePlaceHouses);
		
		JMenuItem mntmUsedPlaceHouses = new JMenuItem("Hotel Name");
		mntmUsedPlaceHouses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Working with dictionary HotelName
				if (frameHotelName == null || !frameHotelName.isDisplayable()) {
					frameHotelName = new HotelName();
					frameHotelName.setVisible(true);
					frameHotelName.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				}
			}
		});
		mnNewMenu_2.add(mntmUsedPlaceHouses);
		
		JMenuItem mntmRegion = new JMenuItem("Region");
		mntmRegion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Working with dictionary Region
				if (frameRegion == null || !frameRegion.isDisplayable()){
					frameRegion = new Region();
					frameRegion.setVisible(true);
					frameRegion.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				}
			}
		});
		mnNewMenu_2.add(mntmRegion);
		
		JMenuItem mntmKindOfDocument = new JMenuItem("Kind of Document");
		mntmKindOfDocument.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Working with dictionary KindOfDoc
				if (frameKindOfDoc  == null || !frameKindOfDoc.isDisplayable()) {
					frameKindOfDoc = new KindOfDoc();
					frameKindOfDoc.setVisible(true);
					frameKindOfDoc.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				}
			}
		});
		mnNewMenu_2.add(mntmKindOfDocument);
		
		JMenu mnExit = new JMenu("Exit");
		menuBar.add(mnExit);
		
		JMenuItem mntmQuit = new JMenuItem("Quit");
		mntmQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			/*
			 * Exit with program
			 */
			System.exit(0);
			}
		});
		mnExit.add(mntmQuit);
		frmSettleToSanatorium.getContentPane().setLayout(null);
	}
}