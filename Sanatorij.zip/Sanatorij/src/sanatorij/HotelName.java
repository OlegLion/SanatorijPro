package sanatorij;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.Font;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JFormattedTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.text.MaskFormatter;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JToggleButton;
import java.sql.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class HotelName extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTable tableHotelName;
	private JLabel lblIDHotelName;
	private JFormattedTextField formattedTextHotelName;

	// refresh data to Hotel Name table
	public void refreshTableHotelName() {
		try {
			String query = "select hotelname_id as 'ID Hotel Name', hotel_name as 'Hotel Name' from hotelname";
			PreparedStatement pst = MainKurort.connect.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			tableHotelName.setModel(new DefaultTableModel(
				new Object[][] {
					{new Integer(1), "Block 1"},
					{new Integer(2), "Block 2"},
					{new Integer(3), "Block 3"},
					{new Integer(4), "Block 4"},
					{new Integer(6), "Extra"},
					{new Integer(5), "Private sector"},
				},
				new String[] {
					"ID Hotel Name", "Hotel Name"
				}
			) {
				boolean[] columnEditables = new boolean[] {
					false, false
				};
				public boolean isCellEditable(int row, int column) {
					return columnEditables[column];
				}
			});
			rs.close();
			pst.close();
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	
	/**
	 * Create the frame.
	 */
	public HotelName() {
		setTitle("Dictionary Hotel Name");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 696, 468);
		getContentPane().setLayout(null);
		
		JLabel lblDictionaryOfHotel = new JLabel("Dictionary of Hotel name");
		lblDictionaryOfHotel.setHorizontalAlignment(SwingConstants.CENTER);
		lblDictionaryOfHotel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblDictionaryOfHotel.setBounds(133, 17, 383, 27);
		getContentPane().add(lblDictionaryOfHotel);
		
		JLabel lblId = new JLabel("Id:");
		lblId.setBounds(21, 55, 54, 21);
		getContentPane().add(lblId);
		
		lblIDHotelName = new JLabel("New label");
		lblIDHotelName.setBounds(96, 55, 46, 21);
		getContentPane().add(lblIDHotelName);
		
		try {
			formattedTextHotelName = new JFormattedTextField(new MaskFormatter("********************"));
		}catch (Exception e){
			e.printStackTrace();
		}
		formattedTextHotelName.setBounds(96, 96, 101, 21);
		getContentPane().add(formattedTextHotelName);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(210, 71, 426, 258);
		getContentPane().add(scrollPane);
		
		tableHotelName = new JTable();
		tableHotelName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// Choice some element with HotelName table
				try {
					int row = tableHotelName.getSelectedRow();
					String findElement = tableHotelName.getValueAt(row, 0).toString();
					String query = "select * from hotelname where hotelname_id = '"+findElement+"' ";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					while (rs.next()) {
						lblIDHotelName.setText(rs.getString("hotelname_id"));
						formattedTextHotelName.setText(rs.getString("hotel_name"));
					}
					
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		scrollPane.setViewportView(tableHotelName);
		
		JLabel lblHotelName = new JLabel("Hotel name:");
		lblHotelName.setBounds(21, 96, 65, 21);
		getContentPane().add(lblHotelName);
		
		JButton btnAdd = new JButton("ADD");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Add hotel name into table HOTELNAME
				try {
					String query = "select * from hotelname where hotel_name = '"+formattedTextHotelName.getText().trim()+"' ";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					ResultSet rs = pst.executeQuery();
					if (!rs.isBeforeFirst()) {
						query = "insert into hotelname (hotel_name) values ('"+formattedTextHotelName.getText().trim()+"')";
						pst = MainKurort.connect.prepareStatement(query);
						pst.execute();
						rs.close();
						pst.close();
						lblIDHotelName.setText("");
						formattedTextHotelName.setText(null);
						refreshTableHotelName();
					}
					else {
						JOptionPane.showMessageDialog(null, "Duplicate hotel name");
					}
				}catch (Exception e) {
					JOptionPane.showMessageDialog(null, "Error add data to table HotelName " + e);
				}
			}
		});
		btnAdd.setBounds(53, 206, 89, 23);
		getContentPane().add(btnAdd);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Update the HotelName table
				try {
					String query = "update hotelname set hotel_name = '"+formattedTextHotelName.getText().trim()+"' where hotelname_id = '"+lblIDHotelName.getText()+"' ";
					PreparedStatement pst = MainKurort.connect.prepareStatement(query);
					pst.execute();
					pst.close();
					lblIDHotelName.setText("");
					formattedTextHotelName.setText(null);
					refreshTableHotelName();
				}catch (Exception e) {
					JOptionPane.showMessageDialog(null, "Error update data to HotelName table " + e);
				}
			}
		});
		btnUpdate.setBounds(53, 253, 89, 23);
		getContentPane().add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// Deleting the data in HotelName table
				int choice = JOptionPane.showConfirmDialog(null, "Are you really want delete data from HotelName table?", "Deleting data from HotelName table", JOptionPane.YES_NO_OPTION);
				if (choice == 0) {
					try {
						String query = "delete from hotelname where hotelname_id = '"+lblIDHotelName.getText()+"' ";
						PreparedStatement pst = MainKurort.connect.prepareStatement(query);
						pst.execute();
						pst.close();
						lblIDHotelName.setText("");
						formattedTextHotelName.setText(null);
						refreshTableHotelName();
					}catch (Exception e) {
						JOptionPane.showMessageDialog(null, "Error deleting data from HotelName table " + e);
					}
				}
				
			}
		});
		btnDelete.setBounds(53, 299, 89, 23);
		getContentPane().add(btnDelete);
		refreshTableHotelName();
	}
}
