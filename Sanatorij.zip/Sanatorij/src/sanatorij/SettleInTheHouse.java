package sanatorij;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JScrollPane;

import net.proteanit.sql.DbUtils;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.table.DefaultTableModel;

public class SettleInTheHouse extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tableSettleInFree;
	private JTable tableGroupHotel;
	
	/**
	 *  Method filltableSettleInFree() filling table1 with free place
	 */
	public void filltableSettleInFree(){
		try{
			String query = "select hn.hotel_name, h.floor, h.room_number, h.amount_places, h.used_places, (h.amount_places - h.used_places) as FREE_PLACES, h.benefits from hotel as h, hotelname as hn where (h.hotelname_id = hn.hotelname_id) order by hn.hotel_name";
			PreparedStatement pst = MainKurort.connect.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			tableSettleInFree.setModel(new DefaultTableModel(
				new Object[][] {
					{"Block 1", new Integer(101), new Integer(2), new Integer(0), new Integer(0), new Long(0L), "1"},
					{"Block 1", new Integer(2), new Integer(112), new Integer(2), new Integer(0), new Long(2L), ""},
					{"Block 1", new Integer(1), new Integer(111), new Integer(2), new Integer(0), new Long(2L), ""},
					{"Block 2", new Integer(203), new Integer(2), new Integer(1), new Integer(3), new Long(-2L), "1"},
					{"Block 2", new Integer(201), new Integer(2), new Integer(0), new Integer(0), new Long(0L), "1"},
					{"Block 2", new Integer(101), new Integer(2), new Integer(0), new Integer(0), new Long(0L), "1"},
					{"Block 2", new Integer(1), new Integer(113), new Integer(2), new Integer(0), new Long(2L), "0"},
					{"Block 2", new Integer(1), new Integer(101), new Integer(2), new Integer(0), new Long(2L), ""},
					{"Block 2", new Integer(202), new Integer(2), new Integer(2), new Integer(1), new Long(1L), "1"},
					{"Block 3", new Integer(101), new Integer(2), new Integer(2), new Integer(1), new Long(1L), "1"},
					{"Extra", new Integer(1), new Integer(101), new Integer(2), new Integer(0), new Long(2L), ""},
				},
				new String[] {
					"hotel_name", "floor", "room_number", "amount_places", "used_places", "FREE_PLACES", "benefits"
				}
			) {
				boolean[] columnEditables = new boolean[] {
					false, false, false, false, false, false, false
				};
				public boolean isCellEditable(int row, int column) {
					return columnEditables[column];
				}
			});
			rs.close();
			pst.close();
		}catch (Exception e){
			JOptionPane.showMessageDialog(null, "Error filling data in the table " + e);
		}
	}
	
	/**
	 *  Filling group table into used/free hotel places
	 */
	public void fillTableGroupHotel() {
		try {
			String query = "select hn.hotel_name, sum(h.amount_places), sum(h.used_places), sum((h.amount_places - h.used_places)) as FREE_PLACES from hotel as h, hotelname as hn where (h.hotelname_id = hn.hotelname_id) group by hn.hotel_name";
			PreparedStatement pst = MainKurort.connect.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			tableGroupHotel.setModel(DbUtils.resultSetToTableModel(rs));
			rs.close();
			pst.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public SettleInTheHouse() {
		setTitle("Settle in the house");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1065, 549);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setToolTipText("The table free place");
		scrollPane.setBounds(10, 41, 1036, 231);
		contentPane.add(scrollPane);
		
		tableSettleInFree = new JTable();
		scrollPane.setViewportView(tableSettleInFree);
		
		JLabel lblFreePlaceIn = new JLabel("Used/Free places in the Sanatorium");
		lblFreePlaceIn.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblFreePlaceIn.setBounds(359, 11, 258, 19);
		contentPane.add(lblFreePlaceIn);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 339, 580, 146);
		contentPane.add(scrollPane_1);
		
		tableGroupHotel = new JTable();
		scrollPane_1.setViewportView(tableGroupHotel);
		
		JLabel lblGroupUsedfreeHotel = new JLabel("Group data used/free hotel places");
		lblGroupUsedfreeHotel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblGroupUsedfreeHotel.setBounds(167, 301, 244, 19);
		contentPane.add(lblGroupUsedfreeHotel);
		filltableSettleInFree();
		fillTableGroupHotel();
	}
}