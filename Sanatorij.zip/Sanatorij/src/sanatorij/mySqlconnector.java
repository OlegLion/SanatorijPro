package sanatorij;
import java.sql.*;

import javax.swing.*;

public class mySqlconnector {
	Connection conn = null;
	/**
	 * connection method
	 */
	public static Connection dbConnector(){
	try{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/kurort", "root", "lion");
		return conn;
	}catch (Exception e){
		JOptionPane.showMessageDialog(null, "Connection failed ");
		return null;
	}	
	}
}