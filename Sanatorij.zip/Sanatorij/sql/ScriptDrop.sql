--<ScriptOptions statementTerminator=";"/>

ALTER TABLE `kurort7`.`hotel` DROP PRIMARY KEY;

ALTER TABLE `kurort7`.`kindofdoc` DROP PRIMARY KEY;

ALTER TABLE `kurort7`.`users` DROP PRIMARY KEY;

ALTER TABLE `kurort7`.`settle_kindofdocs` DROP PRIMARY KEY;

ALTER TABLE `kurort7`.`settle_regions` DROP PRIMARY KEY;

ALTER TABLE `kurort7`.`settle` DROP PRIMARY KEY;

ALTER TABLE `kurort7`.`hotelname` DROP PRIMARY KEY;

ALTER TABLE `kurort7`.`settle_hotels` DROP PRIMARY KEY;

ALTER TABLE `kurort7`.`region` DROP PRIMARY KEY;

ALTER TABLE `kurort7`.`hoteltest` DROP PRIMARY KEY;

ALTER TABLE `kurort7`.`kindofdoc` DROP INDEX `kurort7`.`k_kindofdoc_name`;

ALTER TABLE `kurort7`.`settle_hotels` DROP INDEX `kurort7`.`fk_hotel_id`;

ALTER TABLE `kurort7`.`settle_regions` DROP INDEX `kurort7`.`fk_region_id`;

ALTER TABLE `kurort7`.`settle_kindofdocs` DROP INDEX `kurort7`.`fk_kindofdoc_id`;

ALTER TABLE `kurort7`.`hotelname` DROP INDEX `kurort7`.`k_hotelname`;

ALTER TABLE `kurort7`.`region` DROP INDEX `kurort7`.`k_region_name`;

DROP TABLE `kurort7`.`hotelname`;

DROP TABLE `kurort7`.`region`;

DROP TABLE `kurort7`.`hotel`;

DROP TABLE `kurort7`.`users`;

DROP TABLE `kurort7`.`settle_hotels`;

DROP TABLE `kurort7`.`kindofdoc`;

DROP TABLE `kurort7`.`settle_regions`;

DROP TABLE `kurort7`.`hoteltest`;

DROP TABLE `kurort7`.`settle`;

DROP TABLE `kurort7`.`settle_kindofdocs`;
