--<ScriptOptions statementTerminator=";"/>

CREATE database kurort7;

CREATE TABLE hotelname (
	hotelname_id INT NOT NULL AUTO_INCREMENT,
	hotel_name VARCHAR(20) NOT NULL,
	PRIMARY KEY (hotelname_id)
) ENGINE=InnoDB;    

CREATE TABLE region (
	region_id INT NOT NULL AUTO_INCREMENT,
	region_name VARCHAR(20) NOT NULL,
	PRIMARY KEY (region_id)
) ENGINE=InnoDB;  

CREATE TABLE hotel (
	hotel_id INT NOT NULL AUTO_INCREMENT,
	hotelname_id INT NOT NULL,
	floor INT NOT NULL,
	room_number INT NOT NULL,
	amount_places INT NOT NULL,
	used_places INT DEFAULT 0,
	place1_poseldoc INT DEFAULT 0,
	place2_poseldoc INT DEFAULT 0,
	benefits VARCHAR(70),
	PRIMARY KEY (hotel_id)
) ENGINE=InnoDB;  

CREATE TABLE users (
	id INT NOT NULL AUTO_INCREMENT,
	user VARCHAR(15),
	password VARCHAR(15),
	PRIMARY KEY (id)
) ENGINE=InnoDB; 

CREATE TABLE settle_hotels (
	settle_id INT NOT NULL AUTO_INCREMENT,
	hotel_id INT NOT NULL,
	PRIMARY KEY (settle_id,hotel_id)
) ENGINE=InnoDB; 

CREATE TABLE region (
	region_id INT NOT NULL AUTO_INCREMENT,
	region_name VARCHAR(20) NOT NULL,
	PRIMARY KEY (region_id)
) ENGINE=InnoDB; 

CREATE TABLE kindofdoc (
	kindofdoc_id INT NOT NULL AUTO_INCREMENT,
	kindofdoc_name VARCHAR(20) NOT NULL,
	kindofdoc_price DOUBLE DEFAULT 0.00,
	PRIMARY KEY (kindofdoc_id)
) ENGINE=InnoDB; 

CREATE TABLE settle_regions (
	settle_id INT NOT NULL AUTO_INCREMENT,
	region_id INT NOT NULL,
	PRIMARY KEY (settle_id,region_id)
) ENGINE=InnoDB; 

CREATE TABLE settle (
	settle_id INT NOT NULL AUTO_INCREMENT,
	number_doc INT NOT NULL,
	people_name VARCHAR(30) NOT NULL,
	age INT NOT NULL,
	address VARCHAR(40) NOT NULL,
	date_doc DATE NOT NULL,
	date_settle DATE NOT NULL,
	amount_days INT NOT NULL,
	amount_peoples INT NOT NULL,
	sex VARCHAR(6) NOT NULL,
	date_leaving DATE NOT NULL,
	date_planleaving DATE NOT NULL,
	date_current TIMESTAMP NOT NULL,
	people2_name VARCHAR(30),
	age2 INT DEFAULT 0,
	sex2 VARCHAR(6),
	close_doc BIT,
	last_days INT,
	arrival INT NOT NULL,
	PRIMARY KEY (settle_id)
) ENGINE=InnoDB; 

CREATE TABLE settle_kindofdocs (
	settle_id INT NOT NULL AUTO_INCREMENT,
	kindofdoc_id INT NOT NULL,
	PRIMARY KEY (settle_id,kindofdoc_id)
) ENGINE=InnoDB;

CREATE UNIQUE INDEX k_kindofdoc_name ON kindofdoc (kindofdoc_name ASC);

CREATE INDEX fk_hotel_id ON settle_hotels (hotel_id ASC);

CREATE INDEX fk_region_id ON settle_regions (region_id ASC);

CREATE INDEX fk_kindofdoc_id ON settle_kindofdocs (kindofdoc_id ASC);

CREATE UNIQUE INDEX k_hotelname ON hotelname (hotel_name ASC);

CREATE INDEX k_region_name ON region (region_name ASC);

